function INITIAL_FRAME = initial_frame() 
    INITIAL_FRAME = rand(1, 24);
end