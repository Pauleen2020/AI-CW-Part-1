function population = generate_offspring(parents)
    global GA_PARAMS;

    offspring = {};
    % Elitism: always keep the best parent unchanged
    offspring{end+1} = parents{1};

    while length(offspring) < GA_PARAMS.POPULATION_SIZE
        breeding_parents = choose_parents(parents);
        child = crossover(breeding_parents);
        mutated_child = mutate_child(child, GA_PARAMS.MUTATION_RATE, GA_PARAMS.MAX_MUTATION_ANGLE);
        offspring{end+1} = mutated_child;
    end

    population = offspring;
end

function breeding_parents = choose_parents(parents)
    breeding_parents = { parents{randi(length(parents))}, parents{randi(length(parents))} };
end

function child = crossover(breeding_parents)
    child = zeros(1, length(breeding_parents{1}));
    parent1i = randi(2);
    parent1 = breeding_parents{parent1i};
    parent2 = breeding_parents{3 - parent1i};
    crossover_point = floor(length(parent1) / 2);
    child = [parent1(1:crossover_point), parent2(crossover_point+1:end)];
end

function mutated_child = mutate_child(child, MUTATION_RATE, MAX_MUTATION_ANGLE)
    global GA_PARAMS;
    mutated_child = child;
    for i = 1:length(mutated_child)
        if rand() < MUTATION_RATE
            mutation_value = (rand() * 2 - 1) * MAX_MUTATION_ANGLE;
            mutated_child(i) = mutated_child(i) + mutation_value;
        end
        % Clamp after mutation
        mutated_child(i) = max(GA_PARAMS.MIN_ANGLE, min(GA_PARAMS.MAX_ANGLE, mutated_child(i)));
    end
end
